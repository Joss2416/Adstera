<?php
// prevent browser
if(PHP_SAPI !== 'cli'){ die; }

require 'vendor/autoload.php';
require 'helpers.php';

$keywords = array_chunk(keywords(), isset($argv[2]) ? $argv[2] : count(keywords()));
for ($i = 0; $i < count($keywords); $i++) {
echo "=> generating xml for blogspot #" . $i . "\n";
file_put_contents('export/blogspot-' . $i . '.xml', view('export.blogspot', [
'keywords' => $keywords[$i],
'argv' => $argv
], false));
}