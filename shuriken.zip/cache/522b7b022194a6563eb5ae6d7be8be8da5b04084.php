<style>
	#topbar{  background:#eb593c;  width:100%;  text-align:center;  color:#fff;  padding:5px;  overflow:hidden;  height:43px;  z-index:1000;  font-family:Georgia;  font-size:19px;  line-height:30px;  position:fixed;  bottom:0;  left:0;  border-bottom:3px solid rgb(255,255,255);  box-shadow:1px 1px 5px rgba(0,0,0,.7);
	}

	#topbar a{-webkit-box-shadow:rgba(0,0,0,0.278431) 1px 1px 3px; background:#333;  border-bottom-left-radius:4px;  border-bottom-right-radius:4px;  border-top-left-radius:4px;  border-top-right-radius:4px;  border:none;  box-shadow:rgba(0,0,0,0.278431) 1px 1px 3px;  color:white;  cursor:pointer;  font-size:0.95em;  margin:0px 0px 0px 7px;  outline:none;  padding:2px 10px 1px;  position:relative;  text-decoration:initial}

	#topbar a:hover{  cursor:pointer;background:#444}

	#topbar a:active{  top:1px}

</style>

<div id='topbar'>
  <p>Here is your ad copy. <a href="#your-offer-url" target="_blank">CTA Link &rarr;</a></p>
</div>
